"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireAnyPermission = exports.requirePermission = exports.superAdminOnly = exports.verifiedClientOnly = exports.clientOnly = exports.adminOnly = exports.protect = exports.CLIENT_VERIFIED_STATUSES = exports.CLIENT_LOGIN_ALLOWED_STATUSES = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const User_js_1 = __importDefault(require("../models/User.js"));
const permissions_js_1 = require("../utils/permissions.js");
exports.CLIENT_LOGIN_ALLOWED_STATUSES = ["active", "verified", "pending", "resubmitted", "rejected"];
exports.CLIENT_VERIFIED_STATUSES = ["active", "verified"];
const canUseToken = (user) => {
    if (user.userType === "admin")
        return user.status === "active";
    if (user.userType === "client")
        return exports.CLIENT_LOGIN_ALLOWED_STATUSES.includes(user.status);
    return false;
};
const protect = async (req, res, next) => {
    try {
        let token = null;
        if (req.headers.authorization?.startsWith("Bearer ")) {
            token = req.headers.authorization.split(" ")[1];
        }
        if (!token) {
            return res.status(401).json({ success: false, message: "Not authorized. No token provided." });
        }
        const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
        const user = await User_js_1.default.findById(decoded.id);
        if (!user) {
            return res.status(401).json({ success: false, message: "User not found." });
        }
        if (!canUseToken(user)) {
            return res.status(403).json({ success: false, message: `Account is ${user.status}.` });
        }
        req.user = user;
        next();
    }
    catch (error) {
        return res.status(401).json({ success: false, message: "Not authorized. Invalid token." });
    }
};
exports.protect = protect;
const adminOnly = (req, res, next) => {
    if (!req.user || req.user.userType !== "admin") {
        return res.status(403).json({ success: false, message: "Admin access only." });
    }
    next();
};
exports.adminOnly = adminOnly;
const clientOnly = (req, res, next) => {
    if (!req.user || req.user.userType !== "client") {
        return res.status(403).json({ success: false, message: "Client access only." });
    }
    next();
};
exports.clientOnly = clientOnly;
const verifiedClientOnly = (req, res, next) => {
    if (!req.user || req.user.userType !== "client") {
        return res.status(403).json({ success: false, message: "Client access only." });
    }
    if (!exports.CLIENT_VERIFIED_STATUSES.includes(req.user.status)) {
        return res.status(403).json({
            success: false,
            code: "CLIENT_NOT_VERIFIED",
            status: req.user.status,
            message: "Your account is not yet verified. Please wait for admin approval before using this module.",
        });
    }
    next();
};
exports.verifiedClientOnly = verifiedClientOnly;
const superAdminOnly = (req, res, next) => {
    if (!req.user || req.user.role !== "super_admin") {
        return res.status(403).json({ success: false, message: "Super admin access only." });
    }
    next();
};
exports.superAdminOnly = superAdminOnly;
const requirePermission = (moduleName, action = "view") => {
    return (req, res, next) => {
        // Super Admin has unrestricted access. Admin has full operational
        // access, while account and role administration is protected by
        // superAdminOnly on the specific routes.
        if (["super_admin", "admin"].includes(req.user?.role))
            return next();

        const permissionModule = (0, permissions_js_1.resolvePermissionModule)(moduleName);
        const normalizedPermissions = (0, permissions_js_1.normalizePermissions)(req.user?.permissions || {});
        const allowed = Boolean(normalizedPermissions?.[permissionModule]?.[action]);
        if (!allowed) {
            return res.status(403).json({
                success: false,
                message: `Missing ${action} permission for ${permissionModule}.`,
            });
        }
        next();
    };
};
exports.requirePermission = requirePermission;
const requireAnyPermission = (requirements = []) => {
    return (req, res, next) => {
        if (["super_admin", "admin"].includes(req.user?.role))
            return next();
        const normalizedPermissions = (0, permissions_js_1.normalizePermissions)(req.user?.permissions || {});
        const allowed = requirements.some(([moduleName, action = "view"]) => {
            const permissionModule = (0, permissions_js_1.resolvePermissionModule)(moduleName);
            return Boolean(normalizedPermissions?.[permissionModule]?.[action]);
        });
        if (!allowed) {
            return res.status(403).json({
                success: false,
                message: "Missing permission for this operation.",
            });
        }
        next();
    };
};
exports.requireAnyPermission = requireAnyPermission;
